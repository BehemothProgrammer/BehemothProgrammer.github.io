# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

import bpy
import os
from enum import Enum
from bpy.types import Operator, AddonPreferences
from bpy.props import FloatVectorProperty, FloatProperty, StringProperty, PointerProperty, IntProperty, BoolProperty

# -----------------------------------------------------------------------------
#
class TurokAddonPreferences(AddonPreferences):
    bl_idname = __package__

    def on_sector_alpha_update(self, context):
        from . import kex_utils
        kex_utils.set_sector_mats_alpha()
    #end if
        
    gameDirectory: StringProperty(name="Unzipped Game Folder", subtype='DIR_PATH')
    devDirectory: StringProperty(name="Turok Folder", subtype='DIR_PATH')
    showHiddenData: BoolProperty(name="Show Unimportant Map Data", description="Shows unimportant map data for Sectors, StaticMeshes", default=False)
    sectorAlpha: FloatProperty(name="Sector Alpha Offset", description="Alpha offset for sector materials", default=0.0, min=-1.0, max=1.0, update=on_sector_alpha_update)
    lastMessage: StringProperty() #used for info,error popup messages

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.alignment = 'CENTER'
        row.operator(TUROK_OT_pref_open_readme.bl_idname, icon='HELP', text="View Readme")
        row.operator(TUROK_OT_pref_open_addon_folder.bl_idname, icon='FILE_FOLDER', text="")
        layout.separator()
        if self.gameDirectory == "" or self.devDirectory == "":
            row = layout.row()
            row.alert = True
            row.label(text="You must set the following paths before using this add-on", icon="ERROR")
        #end if
        row = layout.row(align=True)
        if self.gameDirectory == "":
            row.alert = True
        row.prop(self, "gameDirectory")
        row = layout.row(align=True)
        if self.devDirectory == "":
            row.alert = True
        row.prop(self, "devDirectory")
        row = layout.box()
        row = layout.row(align=True)
        row.use_property_split = True
        row.prop(self, "sectorAlpha")
        row = layout.row(align=True)
        row.use_property_split = True
        row.prop(self, "showHiddenData")
    #end func
#end class
# -----------------------------------------------------------------------------
#
class TUROK_OT_pref_open_readme(bpy.types.Operator):
    bl_idname = "turok_pref.open_readme"
    bl_label = "Open Turok Readme File"
    bl_description = "Tries to open the Readme file included with the Turok addon"
    
    def execute(self, context):
        from . import kex_utils
        kex_utils.open_file(os.path.join(os.path.dirname(os.path.realpath(__file__)), "Readme.pdf"))
        return {'FINISHED'}
    #end func
#end class

# -----------------------------------------------------------------------------
#
class TUROK_OT_pref_open_addon_folder(bpy.types.Operator):
    bl_idname = "turok_pref.open_addon_folder"
    bl_label = "Open Turok addon folder"
    bl_description = "Tries to open the Turok addon folder"
    
    def execute(self, context):
        from . import kex_utils
        kex_utils.open_folder(os.path.dirname(os.path.realpath(__file__)))
        return {'FINISHED'}
    #end func
#end class

# -----------------------------------------------------------------------------
#
def register():
    bpy.utils.register_class(TurokAddonPreferences)
    bpy.utils.register_class(TUROK_OT_pref_open_readme)
    bpy.utils.register_class(TUROK_OT_pref_open_addon_folder)
#end func

# -----------------------------------------------------------------------------
#     
def unregister():
    bpy.utils.unregister_class(TurokAddonPreferences)
    bpy.utils.unregister_class(TUROK_OT_pref_open_readme)
    bpy.utils.unregister_class(TUROK_OT_pref_open_addon_folder)
#end func
