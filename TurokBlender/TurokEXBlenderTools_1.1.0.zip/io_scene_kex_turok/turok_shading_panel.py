# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

import bpy
from . import kex_utils

# -----------------------------------------------------------------------------
#
class TurokShadingSettings(bpy.types.PropertyGroup):
    isTexDirCustom: bpy.props.BoolProperty(name="Export To Custom Directory", description="If is turned off will automatically set the texture file path to textures/<TextureFileName> or it's path relative to the turok folder/unzipped game folder", default=False)
    texDir: bpy.props.StringProperty(name="Texture Directory", description='The directory relative to the Turok folder where the texture should be exported to. Default value is "textures"', default="textures", subtype = "FILE_NAME")
    texIndex: bpy.props.IntProperty(name="Texture Index", min=0, max=3)
    mirrored: bpy.props.BoolProperty(name="Mirrored", description='Changes texture wrapping to "mirrored" which flips the texture on the x and y when it repeats')

# -----------------------------------------------------------------------------
#
class TurokShadingPanel(bpy.types.Panel):
    bl_label = "Turok Shading Node"
    bl_idname = "BONE_PT_TurokShadingNodeProp"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = "Node"
    bl_category = "Turok"
    
    @classmethod
    def poll(cls, context):
        return context.active_node is not None

    def draw(self, context):
        node = context.active_node
        if node.type != "TEX_IMAGE":
            return
        
        layout = self.layout
        row = layout.row()
        row.prop(node.t1, "texIndex")
        row = layout.row()
        row.prop(node.t1, "mirrored")
        row = layout.row()
        row.prop(node.t1, "isTexDirCustom")
        if node.t1.isTexDirCustom:
            row = layout.row()
            row = row.split(factor=0.4)
            row.label(text="Texture Directory")
            row.prop(node.t1, "texDir", text="")
        #end if
    #end func
    
#end class

# -----------------------------------------------------------------------------
#
def register():
    bpy.utils.register_class(TurokShadingSettings)
    bpy.utils.register_class(TurokShadingPanel)
    bpy.types.ShaderNodeTexImage.t1 = bpy.props.PointerProperty(type=TurokShadingSettings)
#end func

# -----------------------------------------------------------------------------
#     
def unregister():
    bpy.utils.unregister_class(TurokShadingSettings)
    bpy.utils.unregister_class(TurokShadingPanel)
    del bpy.types.ShaderNodeTexImage.t1
#end func
