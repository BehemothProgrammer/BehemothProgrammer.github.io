# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

import bpy
from . import kex_utils

# -----------------------------------------------------------------------------
#
class TurokVariantIndexsPropGroup(bpy.types.PropertyGroup):
    variantIndex: bpy.props.IntProperty(name="Variant", min=0, max=65535, soft_min=0, soft_max=65535)
#end class

# -----------------------------------------------------------------------------
#
class TUROK_UL_variant_indexs_props(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row()
        row.prop(item, "variantIndex", text=item.name)
    #end func
#end class

# -----------------------------------------------------------------------------
#
class TUROK_OT_add_bone_variant(bpy.types.Operator):
    bl_idname = "turok_bone.variant_add"
    bl_label = "Add Turok Bone Variant"
    bl_description = "Adds a new variant"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == "ARMATURE" and obj.data.bones.active is not None
    #end func
        
    def execute(self, context):
        obj = context.object
        bone = obj.data.bones.active
        v = bone.t1.variants.add()
        v.name = "Variant %d" % (len(bone.t1.variants) - 1)

        return {'FINISHED'}
    #end func
#end class

# -----------------------------------------------------------------------------
#
class TUROK_OT_remove_bone_variant(bpy.types.Operator):
    bl_idname = "turok_bone.variant_remove"
    bl_label = "Remove Turok Bone Variant"
    bl_description = "Removes selected variant"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        if obj is None or obj.type != "ARMATURE":
            return False
            
        bone = obj.data.bones.active
        return bone is not None and len(bone.t1.variants) > 0
    #end func
        
    def execute(self, context):
        obj = context.object
        bone = obj.data.bones.active
        bone.t1.variants.remove(len(bone.t1.variants) - 1)

        return {'FINISHED'}
    #end func
#end class

# -----------------------------------------------------------------------------
#
class TUROK_OT_setup_bone(bpy.types.Operator):
    bl_idname = "turok_bone.setup_bone"
    bl_label = "Setup Turok Bone"
    bl_description = "Sets the bone head/tail position and other settings"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        if obj is None or obj.type != "ARMATURE":
            return False
            
        bone = obj.data.bones.active
        return bone is not None
    #end func
        
    def execute(self, context):
        obj = context.object
        bone = obj.data.bones.active
        boneName = bone.name
        lastMode = context.object.mode
        #Must make obj active and in edit mode to change edit bones
        bpy.context.view_layer.objects.active = obj
        kex_utils.mode_set('EDIT')
        bone = obj.data.edit_bones[boneName]
        bone.use_deform = False
        bone.head = (0.0, 0.0, 0.0)
        bone.tail = (0.0, 0.0000011, 0.0)
        bone.lock = True
        kex_utils.mode_set(lastMode)
        return {'FINISHED'}
    #end func
#end class

# -----------------------------------------------------------------------------
#
class TurokBoneSettings(bpy.types.PropertyGroup):
    boneIndex: bpy.props.IntProperty(name="Bone Index", min=0, max=65535)
    variants: bpy.props.CollectionProperty(name="Variants", type = TurokVariantIndexsPropGroup)
    
    #blender editor props
    variantsIndex: bpy.props.IntProperty(name="", default = -1)
    
    def draw(self, context, panel, obj, bone):
        layout = panel.layout
        
        if obj.data.is_editmode:
            row = layout.row()
            row.label(text="Exit edit mode to edit Turok Bone data")
            return
        #end if
        row = layout.row()
        row.operator(TUROK_OT_setup_bone.bl_idname)
        row = layout.row()
        row.prop(bone.t1, "boneIndex")
        box = layout.box()
        row = box.row()
        variantsText = 'Variants'
        if len(bone.t1.variants) > 0:
            variantsText = 'Variants (%d)' % (len(bone.t1.variants))
        row.label(text=variantsText)
        row = box.row()
        row.template_list('TUROK_UL_variant_indexs_props', "TurokVariantIndexsPropGroup", bone.t1, "variants", bone.t1, "variantsIndex", type='DEFAULT')
        row = box.row()
        row.operator(TUROK_OT_add_bone_variant.bl_idname, text="Add Variant", icon='ADD')
        row.operator(TUROK_OT_remove_bone_variant.bl_idname, text="Remove Variant", icon='REMOVE')
    #end func
#end class

# -----------------------------------------------------------------------------
#
class TurokBonePanel(bpy.types.Panel):
    bl_label = "Turok Bone"
    bl_idname = "BONE_PT_TurokBoneProp"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "bone"

    def draw(self, context):
        obj = context.object
        if obj is None or obj.type != "ARMATURE":
            return
        bone = obj.data.bones.active
        if bone is None:
            return
        
        bone.t1.draw(context, self, obj, bone)
    #end func
#end class

# -----------------------------------------------------------------------------
#
def register():
    bpy.utils.register_class(TurokVariantIndexsPropGroup)
    bpy.utils.register_class(TUROK_UL_variant_indexs_props)
    bpy.utils.register_class(TUROK_OT_add_bone_variant)
    bpy.utils.register_class(TUROK_OT_remove_bone_variant)
    bpy.utils.register_class(TUROK_OT_setup_bone)
    bpy.utils.register_class(TurokBoneSettings)
    bpy.utils.register_class(TurokBonePanel)
    bpy.types.Bone.t1 = bpy.props.PointerProperty(type=TurokBoneSettings)
#end func

# -----------------------------------------------------------------------------
#     
def unregister():
    bpy.utils.unregister_class(TurokVariantIndexsPropGroup)
    bpy.utils.unregister_class(TUROK_UL_variant_indexs_props)
    bpy.utils.unregister_class(TUROK_OT_add_bone_variant)
    bpy.utils.unregister_class(TUROK_OT_remove_bone_variant)
    bpy.utils.unregister_class(TUROK_OT_setup_bone)
    bpy.utils.unregister_class(TurokBoneSettings)
    bpy.utils.unregister_class(TurokBonePanel)
    del bpy.types.Bone.t1
#end func
