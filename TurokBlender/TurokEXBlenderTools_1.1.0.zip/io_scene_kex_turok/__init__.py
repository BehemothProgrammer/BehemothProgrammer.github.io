# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

import bpy

# -----------------------------------------------------------------------------
#
bl_info = {
    "name": "TurokEX Tools",
    "description": "Import and Export models and animations",
    "author": "BehemothProgrammer",
    "version": (1, 1, 0),
    "blender": (2, 81, 16),
    "location": "File > Import-Export",
    "support": "COMMUNITY",
    "category": "Import-Export"}
  
# -----------------------------------------------------------------------------
#
if "bpy" in locals():
    import importlib
    if "kex_utils" in locals():
        importlib.reload(kex_utils)
    if "turok_import_export" in locals():
        importlib.reload(turok_import_export)
    if "kex_lexer" in locals():
        importlib.reload(kex_lexer)
    if "turok_tool_panel" in locals():
        importlib.reload(turok_tool_panel)
    if "turok_object_panel" in locals():
        importlib.reload(turok_object_panel)
    if "turok_material_panel" in locals():
        importlib.reload(turok_material_panel)
    if "turok_bone_panel" in locals():
        importlib.reload(turok_bone_panel)
    if "turok_preferences" in locals():
        importlib.reload(turok_preferences)
    if "turok_import_anim" in locals():
        importlib.reload(turok_import_anim)
    if "turok_import_model" in locals():
        importlib.reload(turok_import_model)
    if "turok_export_model" in locals():
        importlib.reload(turok_export_model)
    if "turok_export_anim" in locals():
        importlib.reload(turok_export_anim)
    if "turok_shading_panel" in locals():
        importlib.reload(turok_shading_panel)
    if "turok_import_map" in locals():
        importlib.reload(turok_import_map)
    if "turok_export_map" in locals():
        importlib.reload(turok_export_map)
    if "kex_archive" in locals():
        importlib.reload(kex_archive)
    if "turok_map" in locals():
        importlib.reload(turok_map)
    if "handlers" in locals():
        importlib.reload(handlers)
#end if

from . import turok_import_export
from . import turok_tool_panel
from . import turok_object_panel
from . import turok_material_panel
from . import turok_bone_panel
from . import turok_shading_panel
from . import turok_preferences
from . import kex_utils
from . import handlers

# -----------------------------------------------------------------------------
#
def register():
    turok_import_export.register()
    turok_tool_panel.register()
    turok_object_panel.register()
    turok_material_panel.register()
    turok_bone_panel.register()
    turok_shading_panel.register()
    turok_preferences.register()
    handlers.register()

    # print("")
    # print("------------------Start Program---------------")
    # print("")
    
    #print(bpy.app.version)
    #print(__package__)
    
    kex_utils.load_turok_defs()
    # print("")
    # print("------------------End Program---------------")
    # print("")
    
#end func
    
# -----------------------------------------------------------------------------
#
def unregister():
    turok_import_export.unregister()
    turok_tool_panel.unregister()
    turok_object_panel.unregister()
    turok_material_panel.unregister()
    turok_bone_panel.unregister()
    turok_shading_panel.unregister()
    turok_preferences.unregister()
    handlers.unregister()
#end func

# -----------------------------------------------------------------------------
#
if __name__ == "__main__":
    register()
#end if
